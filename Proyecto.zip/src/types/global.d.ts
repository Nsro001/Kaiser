declare global {
  interface Window {
    pdfMake: any;
  }
}

export {};
